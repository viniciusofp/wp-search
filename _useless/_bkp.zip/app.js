'use strict';

angular.module('wpReader', ['ngSanitize','ngResource','ngRoute'])
.config(['$httpProvider', function($httpProvider) {
    delete $httpProvider.defaults.headers.common["X-Requested-With"]
}])
.config(function($sceProvider) {
  $sceProvider.enabled(false);
})
.config(function($routeProvider, $locationProvider) {
  $routeProvider
   .when('/', {
    templateUrl: 'posts.html',
    controller: 'Home',

  })
   .when('/:source', {
    templateUrl: 'posts.html',
    controller: 'Single',

  })
   .when('/busca/:termo', {
    templateUrl: 'posts.html',
    controller: 'Busca',

  })
  .otherwise({
    redirectTo: '/'
  });

})
.directive('navigation', function() {
  return {
    templateUrl: 'nav.html',
    link: function () {
            // Get access to the controller itself.
            var ctrl = angular.element('[ng-view]').controller();

            // Get access to the controller's scope.
            var ctrlScope = angular.element('[ng-view]').scope();
        }

  };
})
.service('wp', function ($resource, $q, $http) {
	var wp = []
	$http.get('sites.json')
      .success(function(data) {

		  wp.sites = data
       console.log(wp.sites)
		// Check if API is enabled
		wp.sites.forEach(function (site) {
			var query = $resource( site.apiUrl + "posts")
			.query(function(data) {
				    site.status = true;
				}, function(error) {
				    site.status = false;
				});
			});
			// Ordem alfabética
			wp.sites.sort(function(a, b) {
			    var textA = a.name.toUpperCase();
			    var textB = b.name.toUpperCase();
			    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
			});
        })
       .error(function() {
           defer.reject('could not find someFile.json');
        });

	// Shuffle array function
	function shuffle(array) {
	  var currentIndex = array.length, temporaryValue, randomIndex;
	  while (0 !== currentIndex) {
	    randomIndex = Math.floor(Math.random() * currentIndex);
	    currentIndex -= 1;
	    temporaryValue = array[currentIndex];
	    array[currentIndex] = array[randomIndex];
	    array[randomIndex] = temporaryValue;
	  }
	  return array;
	}
	// Ocurrences function
	function occurrences(string, subString, allowOverlapping) {
	    string += "";
	    subString += "";
	    if (subString.length <= 0) return (string.length + 1);
	    var n = 0,
	        pos = 0,
	        step = allowOverlapping ? 1 : subString.length;

	    while (true) {
	        pos = string.indexOf(subString, pos);
	        if (pos >= 0) {
	            ++n;
	            pos += step;
	        } else break;
	    }
	    return n;
	}
	// Count Words funcion
	function countWords(s){
	    s = s.replace(/(^\s*)|(\s*$)/gi,"");//exclude  start and end white-space
	    s = s.replace(/[ ]{2,}/gi," ");//2 or more space to 1
	    s = s.replace(/\n /,"\n"); // exclude newline with a start spacing
	    return s.split(' ').length; 
	}


	function resumoPost (post) {
		var html = post.content.rendered.replace(/(<([^>]+)>)/ig,"");
		var resumo = html.substr(0, 140);
		var resumo = resumo.substr(0, Math.min(resumo.length, resumo.lastIndexOf(" "))) + " (...)"
		return resumo
	}

	wp.ultimas = function(paginaAtual) {

		var results = [];
		var index = wp.sites.length - 1;
		for (var i = 0 ; i <= wp.sites.length - 1; i++) {

			var posts = $resource( wp.sites[i].apiUrl + "posts?per_page=:perpage", { perpage: 1, page: paginaAtual} ).query();
			$q.all([
			    posts.$promise
			]).then( function (data) { 
				var pst = data[0][0];
				var midia = wp.sites.filter(function( obj ) {
				  return obj.apiUrl == pst._links.self[0].href.split('v2/')[0] + 'v2/';
				});

				if (pst.midia = midia[0] != undefined) {
					pst.midia = midia[0];
				};
				pst.apiUrl = pst._links.self[0].href.split('v2/')[0] + 'v2/';

				pst.resumo = resumoPost(pst) // Resumo do post

				if (pst._links['wp:featuredmedia'] != undefined) {
					//Featured Media
					var featuredmedia = $resource( pst._links['wp:featuredmedia'][0].href).get();
					$q.all([
					    featuredmedia.$promise
					]).then( function (data) {
						pst.featuredmedia = data[0].media_details.sizes;
					}, function (error) {
					});
				} else {
					pst.featuredmedia = false;
				};
					

				var wpm = 250;
				pst.readtime = countWords(pst.content.rendered) / wpm - (countWords(pst.content.rendered) / wpm) % 1 + 1

					

				// Dias atrás
				var today = new Date();
				var date_to_reply = new Date(pst.date);
				var daysFromToday = Math.ceil((today.getTime() - date_to_reply.getTime()) / (1000 * 60 * 60 * 24));
				
				if (daysFromToday < 1080) {
					Array.prototype.push.apply(results, data[0]);
				};

			
			}, function (error) {
			});	
		};
		setTimeout(function(){ results = shuffle(results); }, 1000);
		return results		
	}


	wp.singleSource = function(url, paginaAtual) {

		$('#loading-shit').fadeIn();
		var results = [];
		var index = wp.sites.length - 1;
		var posts = $resource( url + "posts?per_page=:perpage", { perpage: 9, page: paginaAtual} ).query();

		$q.all([
		    posts.$promise
		]).then( function (data) { 

			var psts = data[0];

			psts.forEach(function(pst) {
			  
			  	// Mídia
				var midia = wp.sites.filter(function( obj ) {
				  return obj.apiUrl == pst._links.self[0].href.split('v2/')[0] + 'v2/';
				});
				pst.midia = midia[0];
				pst.apiUrl = pst._links.self[0].href.split('v2/')[0] + 'v2/';

				if (pst._links['wp:featuredmedia'] != undefined) {
					//Featured Media
					var featuredmedia = $resource( pst._links['wp:featuredmedia'][0].href).get();
					$q.all([
					    featuredmedia.$promise
					]).then( function (data) {
						pst.featuredmedia = data[0].media_details.sizes;
					}, function (error) {
					});
				} else {
					pst.featuredmedia = false;
				};

				
				pst.resumo = resumoPost(pst) // Resumo do post

				// Readtime
				var wpm = 200;
				pst.readtime = countWords(pst.content.rendered) / wpm - (countWords(pst.content.rendered) / wpm) % 1 + 1


				// Dias atrás
				var today = new Date();
				var date_to_reply = new Date(pst.date);
				var daysFromToday = Math.ceil((today.getTime() - date_to_reply.getTime()) / (1000 * 60 * 60 * 24));
				
				results.push(pst);
				//Sort
				results.sort(function(a, b){
				    var keyA = new Date(a.date),
				        keyB = new Date(b.date);
				    // Compare the 2 dates
				    if(keyA < keyB) return 1;
				    if(keyA > keyB) return -1;
				    return 0;
				});
			});

				

		
		}).finally(function() {
		$('#loading-shit').fadeOut();
	  });	
		return results		
	}

	
	wp.busca = function (termo, paginaAtual) {
		
		var results = []
		for (var i =  wp.sites.length - 1; i >= 0; i--) {
			var posts = $resource( wp.sites[i].apiUrl + "posts?search=:buscatermo&per_page=:perpage&page=:page", { buscatermo: termo.toLowerCase(), perpage: 1, page: paginaAtual} ).query()
			$q.all([
			    posts.$promise
			]).then( function (data) { 
				var psts = data[0];
				var siteResults = [];

				psts.forEach(function(pst) {
					
					var midia = wp.sites.filter(function( obj ) {
					  return obj.apiUrl == pst._links.self[0].href.split('v2/')[0] + 'v2/';
					});
					pst.midia = midia[0];


					
					pst.resumo = resumoPost(pst) // Resumo do post

					// Ocorrências do termo
					var occContent = occurrences(pst.content.rendered.toLowerCase(), termo.toLowerCase(), true);
					var occExcerpt = occurrences(pst.resumo.toLowerCase(), termo.toLowerCase(), true);
					var occTitle = occurrences(pst.title.rendered.toLowerCase(), termo.toLowerCase(), true);
					pst.occ = occTitle + occContent;
					// Dias atrás
					var today = new Date();
					var date_to_reply = new Date(pst.date);
					var daysFromToday = Math.ceil((today.getTime() - date_to_reply.getTime()) / (1000 * 60 * 60 * 24));

					var ranking = 0;

					if (daysFromToday <= 1) {
						ranking = ranking + 7000
					} else if (daysFromToday <=7 ) {
						ranking = ranking + 3000
					} else if (daysFromToday <= 31) {
						ranking = ranking + 1000
					};

					if (occTitle > 0) {
						ranking = ranking + 5000
					};
					if (occExcerpt > 0) {
						ranking = ranking + 2000
					};
					if (occContent > 10) {
						ranking = ranking + 5000
					} else if (occContent > 4) {
						ranking = ranking + 3000
					} else if (occContent >= 1) {
						ranking = ranking + 1000
					};	
					ranking = ranking - daysFromToday * 0.01
					pst.ranking = ranking
					siteResults.push(pst)				
				});
				// results.push(siteResults)
				Array.prototype.push.apply(results, siteResults);
				results.sort(function(a, b){
				    // var keyA = new Date(a.date),
				    //     keyB = new Date(b.date);
				    var keyA = a.ranking;
				    var keyB = b.ranking;
				    // Compare the 2 dates
				    if(keyA < keyB) return 1;
				    if(keyA > keyB) return -1;
				    return 0;
				});
			}).finally(function() {
		  });

		  	 
		};
		return results
	}
	return wp

})

.controller('FirstCtrl', ['$scope', '$q', 'wp','$location', function($scope, $q, wp, $location) {
  $scope.buscatermo = ''
  setTimeout(function() {
  	$scope.sites = wp.sites;
  }, 500)
  $scope.buscaPosts = []

	
  $scope.closeMenu = function() {
	$('#sections-nav').toggleClass('navOpen');
	$('#wrapper').toggleClass('navOpen');
	$('#nav-inner').toggleClass('navOpen');
	$('#navlayer').toggleClass('navOpen');
}
  $scope.searchSubmit = function() {
  	$location.url('/busca/' + $scope.buscatermo);

  }


  $scope.midiaClass = function (site) {
  	if (! site.status) {
  		return 'not-working'
  	};
  }



}])
.controller('Home', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {
	$scope.midia = {
		name: 'Portal do Jornalimo Independente'
	}
	$scope.paginaAtual = 1;
  	$scope.ultimosPosts = wp.ultimas($scope.paginaAtual);
  	$scope.ultimosPostsProx = wp.ultimas($scope.paginaAtual + 1)
  	$scope.proxPag = function() {
	  	$scope.ultimosPosts = $scope.ultimosPostsProx;
	  	$scope.paginaAtual++
	  	$scope.ultimosPostsProx = wp.ultimas($scope.paginaAtual + 1)
	  	$scope.ultimosPostsPrev = wp.ultimas($scope.paginaAtual -1);
  	}
  	$scope.prevPag = function() {
  		$scope.ultimosPosts = $scope.ultimosPostsPrev;
  		if ($scope.paginaAtual > 0) {$scope.paginaAtual--};
  		$scope.ultimosPostsProx = wp.ultimas($scope.paginaAtual + 1)
  		$scope.ultimosPostsPrev = wp.ultimas($scope.paginaAtual -1);
  	}
}])
.controller('Single', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {
	var midia = wp.sites.filter(function( obj ) {
	  return obj.slug == $routeParams.source;
	});
	$scope.midia = midia[0];
	$scope.paginaAtual = 1;

	$scope.ultimosPosts = wp.singleSource(midia[0].apiUrl, $scope.paginaAtual);
  	$scope.ultimosPostsProx = wp.singleSource(midia[0].apiUrl, $scope.paginaAtual + 1);
  $scope.proxPag = function() {
  	$scope.ultimosPosts = $scope.ultimosPostsProx;
  	$scope.paginaAtual++
  	$scope.ultimosPostsProx = wp.singleSource(midia[0].apiUrl, $scope.paginaAtual + 1);
  	$scope.ultimosPostsPrev = wp.singleSource(midia[0].apiUrl, $scope.paginaAtual - 1);
  }
  $scope.prevPag = function() {
  	$scope.ultimosPosts = $scope.ultimosPostsPrev;
  	if ($scope.paginaAtual > 0) {$scope.paginaAtual--};
  	$scope.ultimosPostsProx = wp.singleSource(midia[0].apiUrl, $scope.paginaAtual + 1);
  	$scope.ultimosPostsPrev = wp.singleSource(midia[0].apiUrl, $scope.paginaAtual - 1);
  }
}])
.controller('Busca', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {
	$scope.paginaAtual = 1;
	$scope.midia = {
		name: decodeURI($routeParams.termo)
	}
	$scope.termobuscado = $scope.buscatermo;
	$scope.ultimosPosts = wp.busca($routeParams.termo, $scope.paginaAtual)
  	$scope.ultimosPostsProx = wp.busca($routeParams.termo, $scope.paginaAtual + 1);
  $scope.proxPag = function() {
  	$scope.ultimosPosts = $scope.ultimosPostsProx;
  	$scope.paginaAtual++
  	$scope.ultimosPostsProx = wp.busca($routeParams.termo, $scope.paginaAtual + 1);
  	$scope.ultimosPostsPrev = wp.busca($routeParams.termo, $scope.paginaAtual - 1);
  }
  $scope.prevPag = function() {
  	$scope.ultimosPosts = $scope.ultimosPostsPrev;
  	if ($scope.paginaAtual > 0) {$scope.paginaAtual--};
  	$scope.ultimosPostsProx = wp.busca($routeParams.termo, $scope.paginaAtual + 1);
  	$scope.ultimosPostsPrev = wp.busca($routeParams.termo, $scope.paginaAtual - 1);
  }
}]);
