#!/bin/bash
cd /Users/vini/Documents/GitHub/WP-Reader;
sass --watch style.scss:style.css --style compressed;