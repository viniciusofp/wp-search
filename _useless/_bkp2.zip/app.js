'use strict';

var app = angular.module('wpReader', ['ngSanitize','ngResource','ngRoute'])
app.config(['$httpProvider', function($httpProvider) {
    delete $httpProvider.defaults.headers.common["X-Requested-With"]
}]);
app.config(function($sceProvider) {
	$sceProvider.enabled(false);
});
app.config(function($routeProvider, $locationProvider) {
	$routeProvider
	.when('/', {
    	templateUrl: 'home.html',
    	controller: 'Home',
  	})
   	.when('/mapa', {
    	templateUrl: 'mapa.html',
    	controller: 'Mapa',
  	})
   	.when('/:source', {
    	templateUrl: 'single.html',
    	controller: 'Single',
  	})
   	.when('/busca/:termo', {
    	templateUrl: 'busca.html',
    	controller: 'Busca',
  	})
   	.when('/cat/:catSlug', {
    	templateUrl: 'cat.html',
    	controller: 'Cat',
  	})
  	.otherwise({
    	redirectTo: '/'
  	});

});
app.directive('navigation', function() {
	return {
    	templateUrl: 'nav.html',
  	};
});
app.directive('postRow', function() {
	return {
    	templateUrl: 'post-row.html',
  	};
});
app.service('wp', function ($resource, $q, $http) {
	var wp = []
	// Define listas de sites
	$http.get('sites.json')
    .success(function(data) {
		function sortAbc (array) {
			array.sort(function(a, b) {
			    var textA = a.name.toUpperCase();
			    var textB = b.name.toUpperCase();
			    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
			});
		}
		sortAbc(data);

    	wp.sites = data;


		wp.sitesCultura = data.filter(function(site) {
			return site.category == 'Cultura e Arte'
		});
		wp.sitesPolitica = data.filter(function(site) {
			return site.category == 'Cidadania e Política'
		});
		wp.sitesGenero = data.filter(function(site) {
			return site.category == 'Gênero'
		});
		wp.sitesMeioAmbiente = data.filter(function(site) {
			return site.category == 'Meio Ambiente'
		});
		// sortAbc(wp.sitesPolitica);
		// sortAbc(wp.sitesCultura);
		// sortAbc(wp.sitesGenero);
		// sortAbc(wp.sitesMeioAmbiente);
    })
   .error(function() {
       defer.reject('could not find someFile.json');
    });

	// Shuffle array function
	function shuffle(array) {
	  var currentIndex = array.length, temporaryValue, randomIndex;
	  while (0 !== currentIndex) {
	    randomIndex = Math.floor(Math.random() * currentIndex);
	    currentIndex -= 1;
	    temporaryValue = array[currentIndex];
	    array[currentIndex] = array[randomIndex];
	    array[randomIndex] = temporaryValue;
	  }
	  return array;
	}
	// Ocurrences function
	function occurrences(string, subString, allowOverlapping) {
	    string += "";
	    subString += "";
	    if (subString.length <= 0) return (string.length + 1);
	    var n = 0,
	        pos = 0,
	        step = allowOverlapping ? 1 : subString.length;

	    while (true) {
	        pos = string.indexOf(subString, pos);
	        if (pos >= 0) {
	            ++n;
	            pos += step;
	        } else break;
	    }
	    return n;
	}
	// Count Words funcion
	function countWords(s){
	    s = s.replace(/(^\s*)|(\s*$)/gi,"");//exclude  start and end white-space
	    s = s.replace(/[ ]{2,}/gi," ");//2 or more space to 1
	    s = s.replace(/\n /,"\n"); // exclude newline with a start spacing
	    return s.split(' ').length; 
	}

	function resumoPost (post) {
		var html = post.content.rendered.replace(/(<([^>]+)>)/ig,"");
		var resumo = html.substr(0, 140);
		var resumo = resumo.substr(0, Math.min(resumo.length, resumo.lastIndexOf(" "))) + " (...)"
		return resumo
	}

	var  getImage = function(pst) {
		if (pst._links['wp:featuredmedia'] != undefined) {
			//Featured Media
			var featuredmedia = $resource( pst._links['wp:featuredmedia'][0].href).get();
			$q.all([
			    featuredmedia.$promise
			]).then( function (data) {
				pst.featuredmedia = data[0].media_details.sizes;
			}, function (error) {
			});
		} else {
			pst.featuredmedia = false;
		};
	}

	var setMidia = function(pst) {
	  	// Mídia
		var midia = wp.sites.filter(function( obj ) {
		  return obj.apiUrl == pst._links.self[0].href.split('v2/')[0] + 'v2/';
		});
		if (pst.midia = midia[0] != undefined) {
			pst.midia = midia[0];
		};
	}

	wp.ultimas = function(siteLista, paginaAtual, porPagina) {
		var results = [];
		siteLista =  shuffle(siteLista);
		var index = siteLista.length - 1;
		for (var i = 0 ; i <= siteLista.length - 1; i++) {
			var posts = $resource( siteLista[i].apiUrl + "posts?per_page=:perpage", { perpage: porPagina, page: paginaAtual} ).query();
			$q.all([
			    posts.$promise
			]).then( function (data) { 
				var psts = data[0];
				psts.forEach(function(pst) {
					setMidia(pst);
					getImage(pst);
					// Resumo do post
					pst.resumo = resumoPost(pst) 
					// Readtime
					var wpm = 200;
					pst.readtime = countWords(pst.content.rendered) / wpm - (countWords(pst.content.rendered) / wpm) % 1 + 1
					// Dias atrás
					var today = new Date();
					var date_to_reply = new Date(pst.date);
					var daysFromToday = Math.ceil((today.getTime() - date_to_reply.getTime()) / (1000 * 60 * 60 * 24));
					
					if (daysFromToday < 365) {
						results.push(pst);
					};
				});
			
			}).finally(function() {
				$('#loading').css('display', 'none');
	 		});		
		};
		return results		
	}

	wp.singleSource = function(url, paginaAtual) {
		var results = [];
		var index = wp.sites.length - 1;
		var posts = $resource( url + "posts?per_page=:perpage", { perpage: 9, page: paginaAtual} ).query();
		$q.all([
		    posts.$promise
		]).then( function (data) { 
			var psts = data[0];
			psts.forEach(function(pst) {
				setMidia(pst);
				getImage(pst);
				// Resumo do post
				pst.resumo = resumoPost(pst) 
				// Readtime
				var wpm = 200;
				pst.readtime = countWords(pst.content.rendered) / wpm - (countWords(pst.content.rendered) / wpm) % 1 + 1
				// Dias atrás
				var today = new Date();
				var date_to_reply = new Date(pst.date);
				var daysFromToday = Math.ceil((today.getTime() - date_to_reply.getTime()) / (1000 * 60 * 60 * 24));
				
				results.push(pst);
				//Sort
				results.sort(function(a, b){
				    var keyA = new Date(a.date),
				        keyB = new Date(b.date);
				    // Compare the 2 dates
				    if(keyA < keyB) return 1;
				    if(keyA > keyB) return -1;
				    return 0;
				});
			});
		}).finally(function() {
			$('#loading').css('display', 'none');
	  });	
		return results		
	}
	
	wp.busca = function (termo, paginaAtual) {
		var results = []
		for (var i =  wp.sites.length - 1; i >= 0; i--) {
			var posts = $resource( wp.sites[i].apiUrl + "posts?search=:buscatermo&per_page=:perpage&page=:page", { buscatermo: termo.toLowerCase(), perpage: 1, page: paginaAtual} ).query()
			$q.all([
			    posts.$promise
			]).then( function (data) { 
				var psts = data[0];
				var siteResults = [];
				psts.forEach(function(pst) {
					
					setMidia(pst);

					getImage(pst);

					pst.resumo = resumoPost(pst) // Resumo do post


					// Ocorrências do termo
					var occContent = occurrences(pst.content.rendered.toLowerCase(), termo.toLowerCase(), true);
					var occExcerpt = occurrences(pst.resumo.toLowerCase(), termo.toLowerCase(), true);
					var occTitle = occurrences(pst.title.rendered.toLowerCase(), termo.toLowerCase(), true);
					pst.occ = occTitle + occContent;
					// Dias atrás
					var today = new Date();
					var date_to_reply = new Date(pst.date);
					var daysFromToday = Math.ceil((today.getTime() - date_to_reply.getTime()) / (1000 * 60 * 60 * 24));

					var ranking = 0;

					if (daysFromToday <= 1) {
						ranking = ranking + 7000
					} else if (daysFromToday <=7 ) {
						ranking = ranking + 3000
					} else if (daysFromToday <= 31) {
						ranking = ranking + 1000
					};

					if (occTitle > 0) {
						ranking = ranking + 5000
					};
					if (occExcerpt > 0) {
						ranking = ranking + 2000
					};
					if (occContent > 10) {
						ranking = ranking + 5000
					} else if (occContent > 4) {
						ranking = ranking + 3000
					} else if (occContent >= 1) {
						ranking = ranking + 1000
					};	
					ranking = ranking - daysFromToday * 0.01
					pst.ranking = ranking
					siteResults.push(pst)				
				});
				// results.push(siteResults)
				Array.prototype.push.apply(results, siteResults);
				results.sort(function(a, b){
				    // var keyA = new Date(a.date),
				    //     keyB = new Date(b.date);
				    var keyA = a.ranking;
				    var keyB = b.ranking;
				    // Compare the 2 dates
				    if(keyA < keyB) return 1;
				    if(keyA > keyB) return -1;
				    return 0;
				});
			}).finally(function() {
				$('#loading').css('display', 'none');
		  });
		};
		return results
	}
	return wp
});
app.controller('MainCtrl', ['$scope', '$q', 'wp','$location', function($scope, $q, wp, $location) {
  	$scope.buscatermo = ''
  	setTimeout(function() {
  		$scope.sites = wp.sites;
		$scope.sitesCultura = wp.sitesCultura;
		$scope.sitesGenero = wp.sitesGenero;
		$scope.sitesPolitica = wp.sitesPolitica;
		$scope.sitesMeioAmbiente = wp.sitesMeioAmbiente;	
  	}, 1000)
	

  	$scope.buscaPosts = []

	
  	$scope.closeMenu = function() {
		$('#sections-nav').removeClass('navOpen');
		$('#wrapper').removeClass('navOpen');
		$('#nav-inner').removeClass('navOpen');
		$('#navlayer').removeClass('navOpen');
	}
	$scope.searchSubmit = function() {
	  	$location.url('/busca/' + $scope.buscatermo);
	  	$scope.closeMenu();

	}

  	$scope.saibaMais = function () {
  		$('.saibamais').toggleClass('hidden')
  	}

  	$scope.midiaClass = function (site) {
  		if (! site.status) {
  			return 'not-working'
  		};
  	}

	$scope.setPosts = function (getPosts) {
		$('#loading').css('display', 'inline');
		setTimeout(function() {
			$("html, body").animate({ scrollTop: $("body") }, "slow");
			$scope.paginaAtual = 1;
			$scope.ultimosPosts = getPosts($scope.paginaAtual);
		  	$scope.ultimosPostsProx = getPosts($scope.paginaAtual + 1);
			$scope.proxPag = function() {
				$('#loading').css('display', 'inline');
				$("html, body").animate({ scrollTop: $("#post-row").offset().top - 60 }, "slow");
			  	$scope.paginaAtual++
			  	$scope.ultimosPosts = getPosts($scope.paginaAtual);
			}
			$scope.prevPag = function() {
				$('#loading').css('display', 'inline');
				$("html, body").animate({ scrollTop: $("#post-row").offset().top - 60 }, "slow");
			  	if ($scope.paginaAtual > 0) {$scope.paginaAtual--};
			  	$scope.ultimosPosts = getPosts($scope.paginaAtual);
			}
		}, 500)
  	}


}]);
app.controller('Home', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {
	$scope.midia = {
		name: 'Portal do Jornalismo Independente',
		linhafina: 'Facilitar o acesso à informação e ao jornalismo independente; popularizar e conectar diversos coletivos espalhados pelo Brasil.',
		description: 'Não só o desenvolvimento tecnológico e a reestruturação do mercado do jornalismo são responsáveis pela expansão do movimento pela mídia livre. A crise do modelo de civilização em que vivemos traz uma série de urgências que têm na comunicação uma ferramenta para gerar mudança.<br><br>As vítimas da crise de refugiados, do racismo, do assédio, das chacinas nas favelas e nos presídios, da exploração do trabalho, do machismo e todas as formas de opressão têm usado a comunicação, sobretudo via internet, para apresentar suas visões da realidade e suas demandas. Todos os anos surgem centenas de coletivos no Brasil que buscam expandir os limites do jornalismo convencional, centralizado em poucos conglomerados que apresentam uma visão unidimensional de mundo.<br><br>O Portal da Mídia Alternativa tem a missão de servir sobretudo a esses produtores de conteúdo, mas também à sua comunidades e ao público em geral, potencializando o alcance, as conexões e a colaboração no universo do jornalismo independente.',
	}
	var getPosts = function (page) {
		return wp.ultimas(wp.sites ,page, 1)
	}

  	$scope.setPosts(getPosts);

}]);
app.controller('Cat', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {
	$scope.midia = {
		name: $routeParams.catSlug,
		linhafina: 'Facilitar o acesso à informação e ao jornalismo independente; popularizar e conectar diversos coletivos espalhados pelo Brasil.',
		description: 'Não só o desenvolvimento tecnológico e a reestruturação do mercado do jornalismo são responsáveis pela expansão do movimento pela mídia livre. A crise do modelo de civilização em que vivemos traz uma série de urgências que têm na comunicação uma ferramenta para gerar mudança.<br><br>As vítimas da crise de refugiados, do racismo, do assédio, das chacinas nas favelas e nos presídios, da exploração do trabalho, do machismo e todas as formas de opressão têm usado a comunicação, sobretudo via internet, para apresentar suas visões da realidade e suas demandas. Todos os anos surgem centenas de coletivos no Brasil que buscam expandir os limites do jornalismo convencional, centralizado em poucos conglomerados que apresentam uma visão unidimensional de mundo.<br><br>O Portal da Mídia Alternativa tem a missão de servir sobretudo a esses produtores de conteúdo, mas também à sua comunidades e ao público em geral, potencializando o alcance, as conexões e a colaboração no universo do jornalismo independente.',
	}
	$scope.sitesLista = $scope.sites;
	if ($routeParams.catSlug == 'meioambiente') {
		var getPosts = function (page) {
			return wp.ultimas(wp.sitesMeioAmbiente, page, 3)
		}
	};
	if ($routeParams.catSlug == 'politica') {
		var getPosts = function (page) {
			return wp.ultimas(wp.sitesPolitica, page, 1)
		}
	};
	if ($routeParams.catSlug == 'cultura') {
		var getPosts = function (page) {
			return wp.ultimas(wp.sitesCultura, page, 2)
		}
	};
	if ($routeParams.catSlug == 'genero') {
		var getPosts = function (page) {
			return wp.ultimas(wp.sitesGenero, page, 4)
		}
	};

  	$scope.setPosts(getPosts);

}]);
app.controller('Single', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {

	var midia = wp.sites.filter(function( obj ) {
	  return obj.slug == $routeParams.source;
	});
	$scope.midia = midia[0];
	var getPosts = function (page) {
		return wp.singleSource(midia[0].apiUrl, page)
	}
  	$scope.setPosts(getPosts);

  	var map;
	function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 5,
          center: {lat: midia[0].lat, lng: midia[0].lng},
          draggable: false,
          fullscreenControl: false,
          scaleControl: false,
          streetViewControl: false,
          scrollwheel: false,
        });
       
    	var marker = new google.maps.Marker({
          position: {lat: midia[0].lat, lng: midia[0].lng},
          map: map,
        });
        var contentString = '<a href="/#/' + midia[0].slug + '"><h5>' + midia[0].name + '</h5></a><p>' + midia[0].linhafina + '</p>';
		var infowindow = new google.maps.InfoWindow({
			content: contentString
		});
		marker.addListener('click', function() {
			infowindow.open(map, marker);
		});

    }
    initMap();
}]);
app.controller('Busca', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {
	$scope.midia = {
		name: decodeURI($routeParams.termo)
	}
	$scope.termobuscado = $scope.buscatermo;
	var getPosts = function (page) {
		return wp.busca($routeParams.termo, page)
	}
  	$scope.setPosts(getPosts);
}]);
app.controller('Mapa', ['$scope', '$q', 'wp', '$routeParams', function($scope, $q, wp, $routeParams) {

  	var map;
	function initMap() {
		var markers = [];
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: {lat: -16.1336219, lng: -51.9039046}
        });
        wp.sites.forEach(function(site) {
        	var marker = new google.maps.Marker({
	          position: {lat: site.lat, lng: site.lng},
	          map: map,
	        });
	        var contentString = '<a href="/#/' + site.slug + '"><h5>' + site.name + '</h5></a><p>' + site.linhafina + '</p>';
			var infowindow = new google.maps.InfoWindow({
				content: contentString
			});
			marker.addListener('click', function() {
				infowindow.open(map, marker);
			});
	        markers.push(marker);
        })
        var markerCluster = new MarkerClusterer(map, markers,
            {
            	imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m',
            	maxZoom: 10,
        	});
    }
    initMap();
}]);
